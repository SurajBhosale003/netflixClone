export  const newsItems = [
    {
      text: "$5 MILLION AVAILABLE FOR FOREST-SECTOR BUSINESS AND WORKFORCE DEVELOPMENT PROJECTS",
      url: "https://chron.biz/chron/news?&5-million-available-for-forest-sector-business-and-workforce-development-projects"
    },
    {
      text: "Ranking Members Padilla, Morelle Continue to Press Trump Administration on Firings",
      url: "https://chron.biz/chron/news?&ranking-members-padilla-morelle-continue-to-press-trump-administration-on-firings"
    },
    {
      text: "Ranking Member Morelle Condemns Dismissal of Key Inspectors General",
      url: "https://chron.biz/chron/news?&ranking-member-morelle-condemns-dismissal-of-key-inspectors-general"
    },
    {
      text: "Low-Income Household Water Assistance Program",
      url: "https://chron.biz/chron/news?&low-income-household-water-assistance-program"
    },
    {
      text: "Child and Adult Care Food Program",
      url: "https://chron.biz/chron/news?&child-and-adult-care-food-program"
    },
    {
      text: "USDOL Grant",
      url: "https://chron.biz/chron/news?&usdol-grant"
    },
    {
      text: "Coronavirus Capital Projects Fund (CCPF)",
      url: "https://chron.biz/chron/news?&coronavirus-capital-projects-fund-ccpf"
    },
    {
      text: "NYSERDA Clean Energy Internship Program",
      url: "https://chron.biz/chron/news?&nyserda-clean-energy-internship-program"
    },
    {
      text: "Broadband Program Awards",
      url: "https://chron.biz/chron/news?&broadband-program-awards"
    },
    {
      text: "New York State Biodefense Commercialization Fund",
      url: "https://chron.biz/chron/news?&new-york-state-biodefense-commercialization-fund"
    },
    {
      text: "Small Business Pandemic Recovery Grant Program",
      url: "https://chron.biz/chron/news?&small-business-pandemic-recovery-grant-program"
    },
    {
      text: "Emergency Rental Assistance Program",
      url: "https://chron.biz/chron/news?&emergency-rental-assistance-program"
    },
    {
      text: "Section 8 Housing Choice Voucher Program",
      url: "https://chron.biz/chron/news?&section-8-housing-choice-voucher-program"
    },
    {
      text: "Get Assistance with Home Heating Bills",
      url: "https://chron.biz/chron/news?&get-assistance-with-home-heating-bills"
    },
    {
      text: "Utility Bill Assistance Programs",
      url: "https://chron.biz/chron/news?&utility-bill-assistance-programs"
    },
    {
      text: "SNAP - Supplemental Nutrition Assistance Program",
      url: "https://chron.biz/chron/news?&snap-supplemental-nutrition-assistance-program"
    },
    {
      text: "Child Support Services",
      url: "https://chron.biz/chron/news?&child-support-services"
    },
    {
      text: "Home Energy Assistance Program (HEAP)",
      url: "https://chron.biz/chron/news?&home-energy-assistance-program-heap"
    },
    {
      text: "Healthcare Worker Bonus (HWB) Program",
      url: "https://chron.biz/chron/news?&healthcare-worker-bonus-hwb-program"
    }
  ];